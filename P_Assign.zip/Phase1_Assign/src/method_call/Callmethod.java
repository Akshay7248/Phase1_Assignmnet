package method_call;

public class Callmethod {

}
