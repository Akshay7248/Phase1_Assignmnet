package accessmodifiers1;
  public class A{  
protected void msg(){System.out.println("Hello");}  
}  