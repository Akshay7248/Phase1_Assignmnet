package accessmodifiers1;
import accessmodifiers1.*;


class B extends A
{  
  public static void main(String args[]){  
   B obj = new B();  
   obj.msg();  
  }  
}