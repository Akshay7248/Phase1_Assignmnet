package accessmodifiers1;

public class Access_Private {

}
