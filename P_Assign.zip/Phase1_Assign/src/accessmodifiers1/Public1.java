package accessmodifiers1;
import accessmodifiers.*;
public class Public1
{
public static void main(String[] args) {
		
		Public obj = new Public(); 
        obj.display();  
		
	}

}
