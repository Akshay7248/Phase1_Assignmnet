package array;

public class queries {

}
