package accessmodifiers3;

class Default_access1
	{ 
	  void display() 
	     { 
	         System.out.println("You are using defalut access specifier"); 
	     } 
	} 	

	public class Default_access {

		public static void main(String[] args) {
			//default
			System.out.println("Dafault Access Specifier");
			Default_access1 obj = new Default_access1(); 		  
	        obj.display(); 

		}
	}
