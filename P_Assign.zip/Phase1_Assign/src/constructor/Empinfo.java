package constructor;

class Emp
{
	int id;
	String name;

void display() {
	System.out.println(id+" "+name);
	}
}

public class Empinfo {

public static void main(String[] args) {

	Emp emp1=new Emp();
	Emp emp2=new Emp();

	emp1.display();
	emp2.display();
	}
}
