package accessmodifiers4;

public class Access_Protecetd {

}
